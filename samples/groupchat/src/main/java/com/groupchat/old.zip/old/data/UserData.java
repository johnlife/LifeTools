package com.groupchat.old.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserData {

    private String name = "";
    private String nickName = "";
    private String eMail = "";
    private String userUniqId = "";
    private String userKey = "";

    public UserData(String json) {
        try {
            JSONObject jsonObject = new JSONObject(json);
            name = jsonObject.getString("name");
            nickName = jsonObject.getString("nickName");
            eMail = jsonObject.getString("eMail");
            userUniqId = jsonObject.getString("userUniqId");
            userKey = jsonObject.getString("userKey");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public UserData(String name, String nickName, String eMail, String userUniqId) {
        this.name = name;
        this.nickName = nickName;
        this.eMail = eMail;
        this.userUniqId = userUniqId;
    }

    public UserData() {

    }

    public String getUserUniqId() {
        return userUniqId;
    }

    public void setUserUniqId(String userUniqId) {
        this.userUniqId = userUniqId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String toJson() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("name", name);
            jsonObject.put("nickName", nickName);
            jsonObject.put("eMail", eMail);
            jsonObject.put("userUniqId", userUniqId);
            jsonObject.put("userKey", userKey);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject.toString();
    }

    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("name", name);
        map.put("nickName", nickName);
        map.put("eMail", eMail);
        map.put("userUniqId", userUniqId);
        map.put("userKey", userKey);
        return map;
    }

    public void setUserKey(String userKey) {
        this.userKey = userKey;
    }

    public String getUserKey() {
        return userKey;
    }
}
