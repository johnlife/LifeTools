package com.groupchat.old.activity;

import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;
import com.groupchat.old.Constants;
import com.groupchat.old.MessageHandler;
import com.groupchat.old.OnItemClickListener;
import com.groupchat.R;
import com.groupchat.old.adapter.ChatAdapter;
import com.groupchat.old.adapter.SuggestionAdapter;
import com.groupchat.old.app.GroupChatApplication;
import com.groupchat.old.data.ChatData;
import com.groupchat.old.data.ChatMessageData;
import com.groupchat.old.data.UserData;
import com.groupchat.old.service.MessageService;
import com.groupchat.old.util.Strings;
import com.quickblox.chat.QBChatService;
import com.quickblox.core.QBEntityCallback;
import com.quickblox.core.QBEntityCallbackImpl;
import com.quickblox.users.QBUsers;
import com.quickblox.users.model.QBUser;
import com.quickblox.videochat.webrtc.QBRTCTypes;

import org.jivesoftware.smack.SmackException;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class OldMainActivity extends BaseActivity implements Constants, OnItemClickListener<ChatMessageData>, MessageHandler {

    private final int MENU_PRIVATE_CHAT = 1;
    private final int MENU_VIDEO_CALL = 2;

    private List<Requester<MessageService>> requesterList = new ArrayList<>();
    private MessageService messageService;
    private String uniqID;
    private RecyclerView list;
    private ChatAdapter chatAdapter;
    private EditText message;
    private UserData user;
    private Firebase firebase;
    private ValueEventListener listener;
    private Toolbar toolbar;
    private SharedPreferences prefs;
    private View send;
    private View parent;
    private Snackbar noInternet;
    private boolean connected = false;
    private List<ChatData> allChats;
    private UserData secondUserItem;
    private ProgressDialog progressDialog;

    @Override
    public void onItemClicked(ChatMessageData item, View itemView, int position) {
        secondUserItem = item.getUser();
        if (!uniqID.equals(secondUserItem.getUserUniqId())) {
            itemView.showContextMenu();
        }
    }

    @Override
    public boolean onItemLongClicked(final ChatMessageData item, View v, int position) {
        //TODO: later
        return true;
    }

    private void openPrivateChat() {
        final String firstUser = uniqID;
        final String secondUser = secondUserItem.getUserUniqId();
        for (int i = 0; i < firstUser.length() && i < secondUser.length(); i++) {
            if (firstUser.charAt(i) > secondUser.charAt(i)) {
                loadChat(new ChatData(getChatName(secondUser, firstUser), true, secondUserItem, false, user, true));
                return;
            } else if (firstUser.charAt(i) < secondUser.charAt(i)) {
                loadChat(new ChatData(getChatName(firstUser, secondUser), true, user, true, secondUserItem, false));
                return;
            }
        }
    }

    private void openVideoCall() {
        QBUsers.getUserByLogin(Strings.SHA1(secondUserItem.getNickName()), new QBEntityCallback<QBUser>() {
            @Override
            public void onSuccess(QBUser qbUser, Bundle bundle) {
                Map<String, String> userInfo = new HashMap<>();
                userInfo.put("any_custom_data", "some data");
                userInfo.put("my_avatar_url", "avatar_reference");
                ArrayList<Integer> a = new ArrayList<Integer>();
                a.add(qbUser.getId());
                CallActivity.start(OldMainActivity.this, QBRTCTypes.QBConferenceType.QB_CONFERENCE_TYPE_VIDEO,
                        a, userInfo, CALL_DIRECTION_TYPE.OUTGOING);
            }

            @Override
            public void onSuccess() {
            }

            @Override
            public void onError(List<String> list) {
            }
        });
    }

    private String getChatName(String firstUser, String secondUser) {
        return new StringBuilder(firstUser).append("=").append(secondUser).toString();
    }

    @Override
    public void addReadedMessage(final String key) {
        requestService(new Requester() {
            @Override
            public void requestService(MessageService service) {
                service.addReadedMessageKey(key);
            }
        });
    }

    public interface Requester<T extends MessageService> {
        void requestService(MessageService service);
    }

    private ServiceConnection serviceConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName name, IBinder binder) {
            connected = true;
            messageService = ((MessageService.ServiceBinder) binder).getService();
            for (Requester<MessageService> requester : requesterList) {
                requester.requestService(messageService);
            }
            requesterList.clear();
        }

        public void onServiceDisconnected(ComponentName name) {
            connected = false;
        }
    };

    public void requestService(Requester requester) {
        if (connected) {
            requester.requestService(messageService);
        } else {
            requesterList.add(requester);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_chat);
        initProgressDialog(getString(R.string.wait_for_loading));
        parent = findViewById(R.id.parent);
        prefs = PreferenceManager.getDefaultSharedPreferences(this);
//        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        try {
            Field titleField = Toolbar.class.getDeclaredField("mTitleTextView");
            titleField.setAccessible(true);
//            TextView barTitleView = (TextView) titleField.get(toolbar);
//            barTitleView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    showSuggestion();
//                }
//            });
        } catch (Exception e){}

        message = (EditText) findViewById(R.id.message);
        message.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!isLogin()) {
                    showInsertNameDialog();
                }
            }
        });
        message.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 0) return;
                if (!isLogin()) {
                    showInsertNameDialog();
                    message.setText("");
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        send = findViewById(R.id.send);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isLogin()) {
                    showInsertNameDialog();
                } else {
                    sendMessage();
                }
            }
        });
        list = (RecyclerView) findViewById(R.id.list);
        allChats = new ArrayList<>();
        firebase = new Firebase(FIREBASE_URL);
        UserData userData;
        if (isLogin()) {
            userData = new UserData("", loggedUser.getFullName(), "", loggedUser.getLogin());
        } else {
            userData = new UserData("", DEFAULT_USERNAME, "", DEFAULT_USERNAME);
        }
        uniqID = userData.getUserUniqId();
        createUser(userData);
        final LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        list.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (null != chatAdapter) {
                    list.post(new Runnable() {
                        @Override
                        public void run() {
                            layoutManager.setStackFromEnd(chatAdapter.getItemCount() > list.getChildCount());
                            list.setLayoutManager(layoutManager);
                            list.smoothScrollToPosition(chatAdapter.getItemCount());
                        }
                    });
                }
            }
        });
        noInternet = Snackbar.make(parent, "", Snackbar.LENGTH_INDEFINITE);
    }

    private void addValueEventListeners() {
        new Firebase(PUBLIC_CHATS).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                hideProgressDialog();
                updateChats(dataSnapshot, false);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {
            }
        });
        new Firebase(PRIVATE_CHATS).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (isLogin()) {
                    updateChats(dataSnapshot, true);
                }
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo){
        menu.setHeaderTitle(getString(R.string.item_click_dialog, secondUserItem.getNickName()));
        menu.add(0, MENU_PRIVATE_CHAT, 0, R.string.open_private);
        menu.add(0, MENU_VIDEO_CALL, 0, R.string.btn_video_call);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if (isLogin()) {
            switch (item.getItemId()) {
                case MENU_PRIVATE_CHAT:
                    openPrivateChat();
                    break;
                case MENU_VIDEO_CALL:
                    openVideoCall();
                    break;
            }
        } else {
            showInsertNameDialog();
        }
        return super.onContextItemSelected(item);
    }

    @Override
    void processCurrentConnectionState(boolean isConnected) {
        showInternetNotification(isConnected);
    }

    private void updateChats(DataSnapshot data, boolean isPrivate) {
        List<ChatData> chats = new ArrayList<>();
        synchronized (allChats) {
            for (int i = 0; i < allChats.size(); i++) {
                ChatData chat = allChats.get(i);
                if (chat.isPrivate() != isPrivate) {
                    chats.add(chat);
                }
            }
            Iterator<DataSnapshot> iterator = data.getChildren().iterator();
            while (iterator.hasNext()) {
                try {
                    ChatData chat = iterator.next().getValue(ChatData.class);
                    if (chat.isInChat(uniqID)) {
                        if (chat.isPrivate() && !chat.isSeen(uniqID)) {
                            showInvite(chat);
                        }
                        chats.add(chat);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            allChats.clear();
            allChats.addAll(chats);
        }
    }

    private void showInvite(final ChatData chat) {
        String nickName = chat.getUser1().getUserUniqId().equals(uniqID) ? chat.getUser2().getNickName() : chat.getUser1().getNickName();
        Snackbar.make(parent, getString(R.string.invite_private_chat, nickName), Snackbar.LENGTH_LONG).setAction(getString(R.string.go_to), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadChat(chat);
            }
        }).show();
    }

    private void createOrUpdateChat(ChatData chat) {
        if (chat.getName().isEmpty()) return;
        new Firebase(chat.isPrivate() ? PRIVATE_CHATS : PUBLIC_CHATS).child(chat.getName()).updateChildren(chat.toMap(uniqID));
    }

    private void loadChat(final ChatData chat) {
        createOrUpdateChat(chat);
        prefs.edit().putString(PREFS_USER_LAST_CHAT, chat.toJson()).apply();
        firebase = GroupChatApplication.getChatMessagesUrl(chat);
        updateToolBarChatName(chat);
        requestService(new Requester() {
            @Override
            public void requestService(MessageService service) {
                service.updateChildChat(chat);
            }
        });
        if (null != chatAdapter) chatAdapter.updateChatRoom(firebase);
    }

    private void updateToolBarChatName(ChatData chat) {
        getSupportActionBar().setTitle(GroupChatApplication.getChatName(chat, uniqID));
    }

    private void init() {
        allChats.clear();
        addValueEventListeners();
        startService(new Intent(OldMainActivity.this, MessageService.class));
        loadChat(new ChatData(GENERAL_CHAT));
        user = new UserData(prefs.getString(PREFS_KEY_USER, "{}"));
        chatAdapter = new ChatAdapter(firebase, R.layout.item_message, uniqID, this, this, this);
        list.setAdapter(chatAdapter);
        registerForContextMenu(list);
        chatAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                list.post(new Runnable() {
                    @Override
                    public void run() {
                        list.smoothScrollToPosition(chatAdapter.getItemCount());
                    }
                });
            }
        });
        bindService(new Intent(this, MessageService.class), serviceConnection, BIND_AUTO_CREATE);
    }

    private void createUser(final UserData user) {
        new Firebase(ALL_USERS).push().setValue(user, new Firebase.CompletionListener() {
            @Override
            public void onComplete(FirebaseError firebaseError, Firebase firebase) {
                String key = firebase.getKey();
                Map<String, Object> map = new HashMap<>();
                map.put("userKey", key);
                user.setUserKey(key);
                prefs.edit().putString(PREFS_KEY_USER, user.toJson()).apply();
                new Firebase(ALL_USERS).child(key).updateChildren(map);
                init();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        if (null != chatAdapter) {
            list.post(new Runnable() {
                @Override
                public void run() {
                    list.smoothScrollToPosition(chatAdapter.getItemCount());
                }
            });
        }
        requestService(new Requester() {
            @Override
            public void requestService(MessageService service) {
                service.setForceRemove(true);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        requestService(new Requester() {
            @Override
            public void requestService(MessageService service) {
                service.setForceRemove(false);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        listener = firebase.getRoot().child(".info/connected").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                boolean connected = (Boolean) dataSnapshot.getValue();
                showInternetNotification(connected);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {}
        });
    }

    private void showInternetNotification(boolean connected) {
        if (connected) {
            noInternet.setText("Connected");
            parent.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (null != noInternet) noInternet.dismiss();
                }
            }, 500);
        } else {
            noInternet.setText("No connection");
            if (null != noInternet) noInternet.show();
        }
    }

    @Override
    protected void onStop() {
        firebase.getRoot().child(".info/connected").removeEventListener(listener);
        super.onStop();
    }

    private void sendMessage() {
        String input = message.getText().toString().trim();
        if (!input.isEmpty()) {
            ChatMessageData m = new ChatMessageData("", "", user, input, false);
            firebase.push().setValue(m);
            message.setText("");
            list.post(new Runnable() {
                @Override
                public void run() {
                    list.smoothScrollToPosition(chatAdapter.getItemCount());
                }
            });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        return super.onCreateOptionsMenu(menu);
    }

    public static int dpToPx(Context context, int dp) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return Math.round(dp * ((float) displayMetrics.densityDpi / (float) DisplayMetrics.DENSITY_DEFAULT));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        requestService(new Requester() {
            @Override
            public void requestService(MessageService service) {
                service.setForceRemove(false);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_search:
                showSuggestion();
                return true;
            case R.id.create_password:
                if (isLogin()) {
                    if (loggedUser.getPassword().equals(DEFAULT_PASSWORD)) {
                        showCreatePasswordDialog();
                    } else {
                        showChangePasswordDialog();
                    }
                }
                return true;
            case R.id.log_out:
                if (isLogin()) {
                    showLogoutDialog();
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CALL_ACTIVITY_CLOSE){
            if (resultCode == CALL_ACTIVITY_CLOSE_WIFI_DISABLED) {
                Toast.makeText(this, getString(R.string.WIFI_DISABLED),Toast.LENGTH_LONG).show();
            }
        } else if (resultCode == LOGIN_RESULT_CODE){
            int loginResult = data.getIntExtra(LOGIN_RESULT, LOGIN_FAILED);
            if (loginResult == LOGIN_SUCCESS) {
                loggedUser = QBChatService.getInstance().getUser();
                if (loggedUser != null) {
                    uniqID = loggedUser.getLogin();
                    createUser(new UserData("", loggedUser.getFullName(), "", loggedUser.getLogin()));
                }
            } else if (loginResult == NEED_PASSWORD) {
                showInsertPasswordDialog(data.getStringExtra(USER_LOGIN));
            }
            hideProgressDialog();
        }
    }

    private void signInOrUp (String login, String password, int signVariant) {
        initProgressDialog(getString(R.string.processes_login));
        startIncomeCallListenerService(login, password, signVariant);
    }

    private void updateUserPassword (String oldPassword, String password) {
        loggedUser.setOldPassword(oldPassword);
        loggedUser.setPassword(password);
        QBUsers.updateUser(loggedUser, new QBEntityCallbackImpl<QBUser>() {
            @Override
            public void onSuccess(QBUser user, Bundle args) {
            }

            @Override
            public void onError(List<String> errors) {
            }
        });
    }


//    DIALOGS    ----------------------------------
    private void initProgressDialog(String message) {
        progressDialog = new ProgressDialog(this) {
            @Override
            public void onBackPressed() {}
        };
        progressDialog.setMessage(message);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
    }

    private void hideProgressDialog() {
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
    }

    private void showInsertNameDialog() {
        View view = getLayoutInflater().inflate(R.layout.dialog_name, null);
        final EditText name = (EditText) view.findViewById(R.id.edit_name);
        new AlertDialog.Builder(this)
                .setTitle(R.string.insert_name)
                .setView(view)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String text = name.getText().toString().trim();
                        if (text.isEmpty()) return;
                        signInOrUp(text, DEFAULT_PASSWORD, SIGNIN);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null).create().show();
    }

    private void showCreatePasswordDialog() {
        final View view = getLayoutInflater().inflate(R.layout.dialog_create_password, null);
        final EditText editText = (EditText) view.findViewById(R.id.edit_password);
        final TextInputLayout passwordWrapper = (TextInputLayout) view.findViewById(R.id.input_layout_password);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(R.string.insert_password)
                .setView(view)
                .setPositiveButton(android.R.string.ok, null)
                .setNegativeButton(android.R.string.cancel, null).create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                passwordWrapper.setError(null);
                String password = editText.getText().toString().trim();
                if (password.isEmpty()) {
                    passwordWrapper.setError(getString(R.string.check_empty_field));
                } else if (password.length() < 8) {
                    passwordWrapper.setError(getString(R.string.check_password_length));
                } else {
                    updateUserPassword(loggedUser.getPassword(), password);
                    dialog.dismiss();
                }
            }
        });
    }

    private void showChangePasswordDialog() {
        final View view = getLayoutInflater().inflate(R.layout.dialog_change_password, null);
        final EditText editOldPassword = (EditText) view.findViewById(R.id.edit_old_password);
        final TextInputLayout oldPasswordWrapper = (TextInputLayout) view.findViewById(R.id.input_layout_old_password);
        final EditText editPassword = (EditText) view.findViewById(R.id.edit_password);
        final TextInputLayout passwordWrapper = (TextInputLayout) view.findViewById(R.id.input_layout_password);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(R.string.change_password)
                .setView(view)
                .setPositiveButton(android.R.string.ok, null)
                .setNegativeButton(android.R.string.cancel, null).create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                oldPasswordWrapper.setError(null);
                passwordWrapper.setError(null);

                String oldPassword = editOldPassword.getText().toString().trim();
                String password = editPassword.getText().toString().trim();

                if (!oldPassword.equals(loggedUser.getPassword())) {
                    oldPasswordWrapper.setError(getString(R.string.wrong_old_password));
                }
                if (password.isEmpty()) {
                    passwordWrapper.setError(getString(R.string.check_empty_field));
                } else if (password.length() < 8) {
                    passwordWrapper.setError(getString(R.string.check_password_length));
                }
                if (oldPasswordWrapper.getError() == null && passwordWrapper.getError() == null) {
                    updateUserPassword(oldPassword, password);
                    dialog.dismiss();
                }
            }
        });
    }

    private void showInsertPasswordDialog(final String login) {
        final View view = getLayoutInflater().inflate(R.layout.dialog_login_with_password, null);
        final TextInputLayout passwordWrapper = (TextInputLayout) view.findViewById(R.id.input_layout_password);
        final TextInputLayout nameWrapper = (TextInputLayout) view.findViewById(R.id.input_layout_name);
        final AlertDialog dialog = new AlertDialog.Builder(this).setView(view).create();
        ((TextView) view.findViewById(R.id.already_know_tv)).setText(String.format(getString(R.string.already_know), login));
        view.findViewById(R.id.ok_password).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                passwordWrapper.setError(null);
                String password = ((EditText) view.findViewById(R.id.edit_password)).getText().toString().trim();
                if (password.isEmpty()) {
                    passwordWrapper.setError(getString(R.string.check_empty_field));
                } else if (password.length() < 8) {
                    passwordWrapper.setError(getString(R.string.check_password_length));
                } else {
                    signInOrUp(login, password, SIGNIN);
                    dialog.dismiss();
                }
            }
        });
        view.findViewById(R.id.ok_name).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nameWrapper.setError(null);
                String name = ((EditText) view.findViewById(R.id.edit_name)).getText().toString().trim();
                if (name.isEmpty()) {
                    nameWrapper.setError(getString(R.string.check_empty_field));
                } else {
                    signInOrUp(name, DEFAULT_PASSWORD, SIGNIN);
                    dialog.dismiss();
                }
            }
        });
        dialog.show();
    }

    private void showLogoutDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.logout_dialog)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            QBChatService.getInstance().logout();
                            stopIncomeCallListenerService();
                            clearUserDataFromPreferences();
                            loadChat(new ChatData(GENERAL_CHAT));
                            UserData userData = new UserData("", DEFAULT_USERNAME, "", DEFAULT_USERNAME);
                            uniqID = userData.getUserUniqId();
                            createUser(userData);
                        } catch (SmackException.NotConnectedException e) {
                            e.printStackTrace();
                        }
                    }
                })
                .setNegativeButton(android.R.string.no, null).create().show();
    }

    public void showSuggestion() {
        View view = getLayoutInflater().inflate(R.layout.search, null);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(view)
                .create();
        Window window = dialog.getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.TOP | Gravity.FILL_HORIZONTAL;
        wlp.x = 0;
        wlp.y=0;
        window.setAttributes(wlp);
        final SuggestionAdapter adapter = new SuggestionAdapter(allChats, this, uniqID, new OnItemClickListener<ChatData>() {
            @Override
            public void onItemClicked(ChatData item, View itemView, int position) {
                loadChat(item);
                dialog.cancel();
            }

            @Override
            public boolean onItemLongClicked(ChatData item, View itemView, int position) {return false;}
        });
        final RecyclerView list = (RecyclerView) view.findViewById(R.id.sugestList);
        list.getLayoutParams().height = dpToPx(OldMainActivity.this, adapter.getItemCount() >= 4 ? 50 * 4 : 50* adapter.getItemCount());
        final EditText text = (EditText) view.findViewById(R.id.search_text);
        final TextWatcher watcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.filter(s.toString(), new Filter.FilterListener() {
                    @Override
                    public void onFilterComplete(int count) {
                        if (count <= 4) {
                            list.getLayoutParams().height = dpToPx(OldMainActivity.this, 50 * count);
                        } else {
                            list.getLayoutParams().height = dpToPx(OldMainActivity.this, 200);
                        }
                    }
                });
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };
        text.addTextChangedListener(watcher);
//        view.findViewById(R.id.clear).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                text.removeTextChangedListener(watcher);
//                text.setText("");
//                adapter.clearFilter();
//                int count = adapter.getItemCount();
//                if (count <= 4) {
//                    list.getLayoutParams().height = dpToPx(OldMainActivity.this, 50 * count);
//                } else {
//                    list.getLayoutParams().height = dpToPx(OldMainActivity.this, 200);
//                }
//                text.addTextChangedListener(watcher);
//            }
//        });
//        view.findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                dialog.cancel();
//            }
//        });
        list.setAdapter(adapter);
        dialog.show();
    }
}