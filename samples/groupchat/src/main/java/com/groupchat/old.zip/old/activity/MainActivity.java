package com.groupchat.old.activity;

import android.support.v7.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

}
