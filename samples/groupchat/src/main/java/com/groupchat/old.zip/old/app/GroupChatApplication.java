package com.groupchat.old.app;

import android.app.Application;
import android.content.SharedPreferences;

import com.firebase.client.Firebase;
import com.groupchat.old.Constants;
import com.groupchat.old.data.ChatData;
import com.quickblox.videochat.webrtc.QBRTCSession;

import org.json.JSONException;
import org.json.JSONObject;

public class GroupChatApplication extends Application implements Constants {

    private static QBRTCSession currentSession;

    @Override
    public void onCreate() {
        super.onCreate();
        Firebase.setAndroidContext(this);
        Firebase.getDefaultConfig().setPersistenceEnabled(true);
    }

    public static ChatData getPrefsChat(SharedPreferences prefs) {
        ChatData chat = null;
        if (prefs.contains(PREFS_USER_LAST_CHAT)) {
            try {
                chat = new ChatData(new JSONObject(prefs.getString(PREFS_USER_LAST_CHAT, null)));
            } catch (JSONException e) {
                chat = new ChatData(GENERAL_CHAT);
            }
        } else {
            chat = new ChatData(GENERAL_CHAT);
        }
        return chat;
    }

    public static Firebase getChatMessagesUrl(ChatData chat) {
        return new Firebase(chat.isPrivate() ? PRIVATE_CHATS : PUBLIC_CHATS).child(chat.getName()).child(MESSAGES);
    }

    public static String getChatName(ChatData chat, String uniqId) {
        String name = "";
        if (chat.isPrivate()) {
            if (uniqId.equals(chat.getUser1().getUserUniqId())) {
                name = chat.getUser2().getNickName();
            } else {
                name = chat.getUser1().getNickName();
            }
        } else {
            name = chat.getName();
        }
        return "#" + name;
    }

    public static QBRTCSession getCurrentSession() {
        return currentSession;
    }

    public static void setCurrentSession(QBRTCSession qbCurrentSession) {
        currentSession = qbCurrentSession;
    }

}