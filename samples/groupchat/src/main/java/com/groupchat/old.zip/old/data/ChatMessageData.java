package com.groupchat.old.data;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ChatMessageData {

    private String key = "";
    @JsonProperty(value = "user")
    private UserData user;
    private String message = "";
    private long time;
    private boolean date = false;

    public ChatMessageData() {}

    public ChatMessageData(String key, String time, UserData user, String message, boolean date) {
        this.user = user;
        this.key = key;
        this.message = message;
        this.date = date;
        this.time = System.currentTimeMillis();
    }

    public ChatMessageData(String time, UserData user, String message, boolean date) {
        this.user = user;
        this.message = message;
        this.time = System.currentTimeMillis();
        this.date = date;
    }

    public UserData getUser() {
        return user;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public long getTime() {
        return time;
    }

    public boolean isDate() {
        return date;
    }

    public void setDate(boolean date) {
        this.date = date;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    @Override
    public String toString() {
        return user.getUserUniqId() + " - " + message + " - " + time;
    }

    @Override
    public boolean equals(Object o) {
        return null != o && (o instanceof ChatMessageData) && ((ChatMessageData) o).getKey().equals(key);
    }
}
