package com.groupchat.old.service;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.support.v7.app.NotificationCompat;

import com.firebase.client.ChildEventListener;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;
import com.groupchat.old.Constants;
import com.groupchat.R;
import com.groupchat.old.activity.OldMainActivity;
import com.groupchat.old.app.GroupChatApplication;
import com.groupchat.old.data.ChatData;
import com.groupchat.old.data.ChatMessageData;
import com.groupchat.old.data.UserData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MessageService extends Service implements Constants {

    private ServiceBinder binder = new ServiceBinder();
    private NotificationManager notificationManager;
    private NotificationCompat.Builder builder;
    private String uniqID;
    private Firebase firebase;
    private ChildEventListener childEventListener;
    private boolean forceRemove = false;
    private Firebase userFirebase;
    private UserData user;
    private List<String> readedMessages = new ArrayList<>();

    public class ServiceBinder extends Binder {
        public MessageService getService() {
            return MessageService.this;
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        user = new UserData(PreferenceManager.getDefaultSharedPreferences(this).getString(PREFS_KEY_USER, ""));
        uniqID = user.getUserUniqId();
        return START_STICKY;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        initNotification();
        ChatData chat = GroupChatApplication.getPrefsChat(PreferenceManager.getDefaultSharedPreferences(this));
        user = new UserData(PreferenceManager.getDefaultSharedPreferences(this).getString(PREFS_KEY_USER, ""));
        uniqID = user.getUserUniqId();
        userFirebase = new Firebase(ALL_USERS).child(user.getUserKey());
        userFirebase.child(MESSAGES).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                try {
                    HashMap<String, Object> hashMaps = (HashMap<String, Object>) dataSnapshot.getValue();
                        for (String key: hashMaps.keySet()) {
                            readedMessages.add((String) hashMaps.get(key));
                        }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });
        firebase = GroupChatApplication.getChatMessagesUrl(chat);
        firebase.addChildEventListener(getOnlineEventListener());
    }

    public void updateChildChat(ChatData chat) {
        if (null != childEventListener) firebase.removeEventListener(childEventListener);
        firebase = GroupChatApplication.getChatMessagesUrl(chat);
        firebase.addChildEventListener(getOnlineEventListener());
    }

    private ChildEventListener getOnlineEventListener() {
        childEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                try {
                    ChatMessageData model = dataSnapshot.getValue(ChatMessageData.class);
                    String key = dataSnapshot.getKey();
                    if (model.getUser().getUserUniqId().equals(uniqID)) return;
                    if (!forceRemove && !readedMessages.contains(key)) {
                        MessageService.this.notify(model);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {
            }
        };
        return childEventListener;
    }

    private void notify(ChatMessageData model) {
        builder.setTicker(model.getMessage());
        builder.setContentTitle(model.getUser().getNickName())
                .setContentText(model.getMessage());
        notificationManager.notify(0, builder.build());
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    private void initNotification() {
        builder = new NotificationCompat.Builder(this);
        builder.setSmallIcon(R.mipmap.ic_launcher);
        builder.setAutoCancel(true);
        Intent i = new Intent(this, OldMainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        builder.setOnlyAlertOnce(false);
        builder.setContentIntent(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT));
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        builder.setSound(alarmSound);
    }

    public void setForceRemove(boolean forceRemove) {
        this.forceRemove = forceRemove;
    }

    public void addReadedMessageKey(String key) {
        if (!forceRemove || readedMessages.contains(key)) return;
        readedMessages.add(key);
        Map<String, Object> map = new HashMap<>();
        map.put(key, key);
        userFirebase.child("messages").updateChildren(map);
    }

}