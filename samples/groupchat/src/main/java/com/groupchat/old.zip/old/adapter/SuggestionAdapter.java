package com.groupchat.old.adapter;

import android.content.Context;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import com.groupchat.old.OnItemClickListener;
import com.groupchat.R;
import com.groupchat.old.app.GroupChatApplication;
import com.groupchat.old.data.ChatData;

import java.util.ArrayList;
import java.util.List;

public class SuggestionAdapter extends RecyclerView.Adapter<SuggestionAdapter.SuggestionViewHolder> {

    private List<ChatData> items;
    private String uniqId;
    private List<ChatData> originalItems;
    private Context context;
    private OnItemClickListener onItemClickListener;
    private ResultFilter filter;

    public SuggestionAdapter(List<ChatData> items, Context context, String uniqId, OnItemClickListener onItemClickListener) {
        this.items = new ArrayList<>(items);
        this.uniqId = uniqId;
        this.context = context;
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public void onBindViewHolder(final SuggestionViewHolder holder, final int position) {
        holder.chatName.setText(GroupChatApplication.getChatName(items.get(position), uniqId));
        holder.chatIcon.setImageResource(items.get(position).isPrivate() ? R.drawable.ic_person_outline_black_18dp
                : R.drawable.ic_people_outline_black_18dp);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != onItemClickListener) onItemClickListener.onItemClicked(items.get(position), holder.itemView, position);
            }
        });
    }

    @Override
    public void onBindViewHolder(SuggestionViewHolder holder, int position, List<Object> payloads) {
        super.onBindViewHolder(holder, position, payloads);
    }


    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        recyclerView.setItemAnimator(getAnimation());
        recyclerView.setLayoutManager(getLayoutManager(getContext()));
    }

    protected RecyclerView.LayoutManager getLayoutManager(Context context) {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        return linearLayoutManager;
    }

    protected DefaultItemAnimator getAnimation() {
        return new DefaultItemAnimator();
    }

    @Override
    public SuggestionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(getContext()).inflate(R.layout.suggesstion_item, parent, false);
        return new SuggestionViewHolder(v);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class SuggestionViewHolder extends RecyclerView.ViewHolder {

        private TextView chatName;
        private ImageView chatIcon;

        public SuggestionViewHolder(View itemView) {
            super(itemView);
            chatIcon = (ImageView) itemView.findViewById(R.id.chat_icon);
            chatName = (TextView) itemView.findViewById(R.id.suggest_item_name);
        }
    }

    public Context getContext() {
        return context;
    }

    public void filter (String s) {
        if (null == filter) {
            filter = new ResultFilter();
        }
        filter.filter(s);
    }

    public void filter (String s, ResultFilter.FilterListener listener) {
        if (null == filter) {
            filter = new ResultFilter();
        }
        filter.filter(s, listener);
    }

    public void clearFilter() {
        if (null == filter || null == originalItems) {
            return;
        }
        filter = null;
        items.clear();
        items.addAll(originalItems);
        notifyDataSetChanged();
        originalItems = null;
    }

    private class ResultFilter extends Filter {

        FilterResults results;

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            results = new FilterResults();
            String prefix = constraint.toString().toLowerCase();
            if (originalItems == null) {
                originalItems = new ArrayList<>(items);
            }
            if (prefix.length() == 0) {
                List<ChatData> list = new ArrayList<>(originalItems);
                results.values = list;
                results.count = list.size();
            } else {
                List<ChatData> list = new ArrayList<>(originalItems);
                List<ChatData> nlist = new ArrayList<>();
                int count = list.size();
                for (int i = 0; i < count; i++) {
                    ChatData data = list.get(i);
                    String value = GroupChatApplication.getChatName(data, uniqId).toLowerCase();
                    if (value.contains(prefix)) {
                        nlist.add(data);
                    }
                    results.values = nlist;
                    results.count = nlist.size();
                }
            }
            return results;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, final FilterResults results) {
            if (null == results.values) return;
            items = (List<ChatData>) results.values;
            notifyDataSetChanged();
        }
    }
}
