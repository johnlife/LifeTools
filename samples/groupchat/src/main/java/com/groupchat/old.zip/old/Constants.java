package com.groupchat.old;

import com.groupchat.old.util.Strings;

public interface Constants {

    String FIREBASE_URL = "https://upmobilechat.firebaseio.com/";
    String CHATS = FIREBASE_URL + "Chats/";
    String PUBLIC_CHATS = CHATS + "Public/";
    String PRIVATE_CHATS = CHATS + "Private/";
    String USERS = FIREBASE_URL + "Users/";
    String ALL_USERS = USERS + "AllUsers/";

    String PREFS_USER_LAST_CHAT = "prefs.user.last.chat";
    String PREFS_KEY_USER = "prefs.key.user";

    String GENERAL_CHAT = "general";
    String MESSAGES = "messages";


    String APP_ID = "30146";
    String AUTH_KEY = "dX5Os8Ca7KTjnOS";
    String AUTH_SECRET = "nqVmM-qxFFOBxCf";

    String DEFAULT_PASSWORD = Strings.SHA1("12345678");
    String DEFAULT_USERNAME = "username";

    int NOTIFICATION_FORAGROUND = 1004;
    int NOTIFICATION_CONNECTION_LOST = 1005;

    int CALL_ACTIVITY_CLOSE = 1000;
    int LOGIN_TASK_CODE = 1002;
    int LOGIN_RESULT_CODE = 1003;

    String CALL_RESULT = "call_result";
    String CALL_ACTION_VALUE = "call_action_value";

    int RECEIVE_NEW_SESSION = 11110;
    int USER_NOT_ANSWER = 11111;
    int CALL_REJECT_BY_USER = 11112;
    int RECEIVE_HANG_UP_FROM_USER = 11113;
    int SESSION_CLOSED = 11114;
    int SESSION_START_CLOSE = 11115;

    int START_CONNECT_TO_USER = 22220;
    int CONNECTED_TO_USER = 22221;
    int CONNECTION_CLOSED_FOR_USER = 22222;
    int DISCONNECTED_FROM_USER = 22223;
    int DISCONNECTED_TIMEOUT_FROM_USER = 22224;
    int CONNECTION_FAILED_WITH_USER = 22225;
    int ERROR = 22226;

    //Start service variant
    String START_SERVICE_VARIANT = "start_service_variant";
    int AUTOSTART = 1006;
    int RELOGIN = 1007;
    int SIGNIN = 1008;
    int SIGNUP = 1009;

    int NEED_PASSWORD = 1010;
    int LOGIN_SUCCESS = 1011;
    int LOGIN_FAILED = 1012;


    String PARAM_PINTENT = "pendingIntent";
    String LOGIN_RESULT = "result";

    //Shared Preferences constants
    String USER_LOGIN = "user_login";
    String USER_PASSWORD = "user_password";
    String USER_ID = "user_id";

    long ANSWER_TIME_INTERVAL = 45l;

    //CALL ACTIVITY CLOSE REASONS
    int CALL_ACTIVITY_CLOSE_WIFI_DISABLED = 1001;
    String WIFI_DISABLED = "wifi_disabled";

    String OPPONENTS_LIST_EXTRAS = "opponents_list";
    String CALL_DIRECTION_TYPE_EXTRAS = "call_direction_type";
    String CALL_TYPE_EXTRAS = "call_type";
    String USER_INFO_EXTRAS = "user_info";
    String SHARED_PREFERENCES = "preferences";
    String QB_EXCEPTION_EXTRAS = "exception";

    String UNKNOWN_USER = "Unknown user";

    enum CALL_DIRECTION_TYPE {
        INCOMING,
        OUTGOING
    }
}
