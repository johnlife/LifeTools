package com.groupchat.old.activity;

import android.annotation.TargetApi;
import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;

import com.groupchat.R;
import com.groupchat.old.app.GroupChatApplication;
import com.groupchat.old.fragment.IncomeCallFragment;
import com.groupchat.old.fragment.VideoConversationFragment;
import com.quickblox.videochat.webrtc.QBRTCClient;
import com.quickblox.videochat.webrtc.QBRTCConfig;
import com.quickblox.videochat.webrtc.QBRTCException;
import com.quickblox.videochat.webrtc.QBRTCSession;
import com.quickblox.videochat.webrtc.QBRTCTypes;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class CallActivity extends BaseActivity {


    private static final String TAG = CallActivity.class.getSimpleName();
    public static final String INCOME_CALL_FRAGMENT = "income_call_fragment";
    public static final String CONVERSATION_CALL_FRAGMENT = "conversation_call_fragment";

    private Runnable showIncomingCallWindowTask;
    private Handler showIncomingCallWindowTaskHandler;
    private boolean closeByWifiStateAllow = true;
    private String hangUpReason;
    private boolean isInCommingCall;
    private CALL_DIRECTION_TYPE call_direction_type;
    private QBRTCTypes.QBConferenceType call_type;
    private List<Integer> opponentsList;
    private MediaPlayer ringtone;
    private BroadcastReceiver callBroadcastReceiver;

    public static void start(Context context, QBRTCTypes.QBConferenceType qbConferenceType,
                             List<Integer> opponentsIds, Map<String, String> userInfo,
                             CALL_DIRECTION_TYPE callDirectionType){
        Intent intent = new Intent(context, CallActivity.class);
        intent.putExtra(CALL_DIRECTION_TYPE_EXTRAS, callDirectionType);
        intent.putExtra(CALL_TYPE_EXTRAS, qbConferenceType);
        intent.putExtra(USER_INFO_EXTRAS, (Serializable) userInfo);
        intent.putExtra(OPPONENTS_LIST_EXTRAS, (Serializable) opponentsIds);
        if (callDirectionType == CALL_DIRECTION_TYPE.INCOMING) {
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call);
        registerCallbackListener();

        if (getIntent().getExtras() != null) {
            parseIntentExtras(getIntent().getExtras());
        }
        if (call_direction_type == CALL_DIRECTION_TYPE.INCOMING){
            isInCommingCall = true;
            addIncomeCallFragment(GroupChatApplication.getCurrentSession());

        } else if (call_direction_type == CALL_DIRECTION_TYPE.OUTGOING){
            isInCommingCall = false;
            addConversationFragment(opponentsList, call_type, call_direction_type);
        }
    }

    private void parseIntentExtras(Bundle extras) {
        call_direction_type = (CALL_DIRECTION_TYPE) extras.getSerializable(CALL_DIRECTION_TYPE_EXTRAS);
        call_type = (QBRTCTypes.QBConferenceType) extras.getSerializable(CALL_TYPE_EXTRAS);
        opponentsList = (List<Integer>) extras.getSerializable(OPPONENTS_LIST_EXTRAS);
    }

    @Override
    void processCurrentConnectionState(boolean isConnected) {
        if (!isConnected) {
            Log.d(TAG, "Internet is turned off");
            if (closeByWifiStateAllow) {
                if (GroupChatApplication.getCurrentSession() != null) {
                    Log.d(TAG, "currentSession NOT null");
                    // Close session safely
                    disableConversationFragmentButtons();
                    stopOutBeep();

                    hangUpCurrentSession();

                    hangUpReason = WIFI_DISABLED;
                } else {
                    Log.d(TAG, "Call finish() on activity");
                    finish();
                }
            }
        } else {
            Log.d(TAG, "Internet is turned on");
        }
    }

    private void disableConversationFragmentButtons() {
        VideoConversationFragment fragment = (VideoConversationFragment) getFragmentManager().findFragmentByTag(CONVERSATION_CALL_FRAGMENT);
        if (fragment != null) {
            fragment.actionButtonsEnabled(false);
        }
    }

    private void initIncommingCallTask() {
        showIncomingCallWindowTaskHandler = new Handler(Looper.myLooper());
        showIncomingCallWindowTask = new Runnable() {
            @Override
            public void run() {
                IncomeCallFragment incomeCallFragment = (IncomeCallFragment) getFragmentManager().findFragmentByTag(INCOME_CALL_FRAGMENT);
                if (incomeCallFragment == null) {
                    VideoConversationFragment conversationFragment = (VideoConversationFragment) getFragmentManager().findFragmentByTag(CONVERSATION_CALL_FRAGMENT);
                    if (conversationFragment != null) {
                        disableConversationFragmentButtons();
                        stopOutBeep();
                        hangUpCurrentSession();
                    }
                } else {
                    rejectCurrentSession();
                    finish();
                }
            }
        };
    }

    public void rejectCurrentSession() {
        if (GroupChatApplication.getCurrentSession() != null) {
            Map<String, String> params = new HashMap<>();
            params.put("reason", "manual");
            GroupChatApplication.getCurrentSession().rejectCall(params);
        }
    }

    public void hangUpCurrentSession() {
        if (GroupChatApplication.getCurrentSession() != null) {
            GroupChatApplication.getCurrentSession().hangUp(new HashMap<String, String>());
        }
        finish();
    }

    private void startIncomeCallTimer() {
        showIncomingCallWindowTaskHandler.postAtTime(showIncomingCallWindowTask, SystemClock.uptimeMillis() + TimeUnit.SECONDS.toMillis(QBRTCConfig.getAnswerTimeInterval()));
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    private void stopIncomeCallTimer() {
        Log.d(TAG, "stopIncomeCallTimer");
        showIncomingCallWindowTaskHandler.removeCallbacks(showIncomingCallWindowTask);
    }


    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopOutBeep();
    }

    private void forbidenCloseByWifiState() {
        closeByWifiStateAllow = false;
    }


    // ---------------Chat callback methods implementation  ----------------------//

    public void onReceiveNewSession(){
    }

    public void onUserNotAnswer(Integer userID) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        });
    }

    public void onStartConnectToUser(Integer userID) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                stopOutBeep();
            }
        });
    }

    public void onCallRejectByUser (Integer userID, Map<String, String> userInfo) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                stopOutBeep();
                finish();
            }
        });
    }

    public void onConnectionClosedForUser(Integer userID) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // Close app after session close of network was disabled
                Log.d(TAG, "onConnectionClosedForUser()");
                if (hangUpReason != null && hangUpReason.equals(WIFI_DISABLED)) {
                    Intent returnIntent = new Intent();
                    setResult(CALL_ACTIVITY_CLOSE_WIFI_DISABLED, returnIntent);
                    finish();
                }
            }
        });
    }

    public void onConnectedToUser(final Integer userID) {
        forbidenCloseByWifiState();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isInCommingCall) {
                    stopIncomeCallTimer();
                }
                VideoConversationFragment fragment = (VideoConversationFragment) getFragmentManager().findFragmentByTag(CONVERSATION_CALL_FRAGMENT);
                if (fragment != null) {
                    fragment.actionButtonsEnabled(true);
                }
            }
        });
    }

    public void onDisconnectedTimeoutFromUser(Integer userID) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                hangUpCurrentSession();
            }
        });
    }

    public void onConnectionFailedWithUser(Integer userID) {}

    public void onError(QBRTCException e) {
    }

    public void onSessionClosed() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                    if (isInCommingCall) {
                        stopIncomeCallTimer();
                        Log.d(TAG, "isInCommingCall - " + isInCommingCall);
                    }

                    GroupChatApplication.setCurrentSession(null);

                    Log.d(TAG, "Stop session");
                    closeByWifiStateAllow = true;
                    finish();
            }
        });
    }

    public void onSessionStartClose() {
        stopOutBeep();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                disableConversationFragmentButtons();
            }
        });
    }

    public void onDisconnectedFromUser(Integer userID) {}

    public void onReceiveHangUpFromUser(final Integer userID) {
            finish();
    }

    private void addIncomeCallFragment(QBRTCSession session) {
        if(session != null) {
            initIncommingCallTask();
            startIncomeCallTimer();
            Fragment fragment = new IncomeCallFragment();
            getFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment, INCOME_CALL_FRAGMENT).commit();
        } else {
            Log.d(TAG, "SKIP addIncomeCallFragment method");
            finish();
        }
    }

    public void addConversationFragment (List<Integer> opponents,
                                          QBRTCTypes.QBConferenceType qbConferenceType,
                                          CALL_DIRECTION_TYPE callDirectionType){

        if (GroupChatApplication.getCurrentSession() == null && callDirectionType == CALL_DIRECTION_TYPE.OUTGOING){
            startOutBeep();
            try {
                QBRTCSession newSessionWithOpponents = QBRTCClient.getInstance().createNewSessionWithOpponents(opponents, qbConferenceType);
                GroupChatApplication.setCurrentSession(newSessionWithOpponents);
                Log.d(TAG, "addConversationFragmentStartCall. Set session " + newSessionWithOpponents);

            } catch (IllegalStateException e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }

        VideoConversationFragment fragment = new VideoConversationFragment();

        Bundle bundle = new Bundle();
        bundle.putInt(CALL_DIRECTION_TYPE_EXTRAS, callDirectionType.ordinal());
        fragment.setArguments(bundle);

        getFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment, CONVERSATION_CALL_FRAGMENT).commit();
    }

    private void startOutBeep() {
        ringtone = MediaPlayer.create(this, R.raw.beep);
        ringtone.setLooping(true);
        ringtone.start();
    }

    public void stopOutBeep() {
        if (ringtone != null) {
            try {
                ringtone.stop();
            } catch (IllegalStateException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            ringtone.release();
            ringtone = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (!closeByWifiStateAllow) {
            if (GroupChatApplication.getCurrentSession() != null) {
                if (GroupChatApplication.getCurrentSession().getState() == QBRTCSession.QBRTCSessionState.QB_RTC_SESSION_ACTIVE) {
                    hangUpCurrentSession();
                } else if (GroupChatApplication.getCurrentSession().getState() == QBRTCSession.QBRTCSessionState.QB_RTC_SESSION_NEW) {
                    rejectCurrentSession();
                }
            }
        }
        GroupChatApplication.setCurrentSession(null);
        unregisterReceiver(callBroadcastReceiver);
    }

    @Override
    public void onAttachedToWindow() {
        this.getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
    }

    @Override
    public void onBackPressed() {
    }

    private void registerCallbackListener(){
        callBroadcastReceiver = new BroadcastReceiver() {

            public void onReceive(Context context, Intent intent) {

                if (intent.getAction().equals(CALL_RESULT)){

                    int callTask = intent.getIntExtra(CALL_ACTION_VALUE, 0);
                    final Integer userID = intent.getIntExtra(USER_ID, 0);
                    final Map<String, String> userInfo = (Map<String, String>) intent
                            .getSerializableExtra(USER_INFO_EXTRAS);
                    final QBRTCException exception = (QBRTCException) intent
                            .getSerializableExtra(QB_EXCEPTION_EXTRAS);

                    switch (callTask) {
                        case RECEIVE_NEW_SESSION:
                            onReceiveNewSession();
                            break;
                        case USER_NOT_ANSWER:
                            onUserNotAnswer(userID);
                            break;
                        case CALL_REJECT_BY_USER:
                            onCallRejectByUser(userID, userInfo);
                            break;
                        case RECEIVE_HANG_UP_FROM_USER:
                            onReceiveHangUpFromUser(userID);
                            break;
                        case SESSION_CLOSED:
                            onSessionClosed();
                            break;
                        case SESSION_START_CLOSE:
                            onSessionStartClose();
                            break;
                        case START_CONNECT_TO_USER:
                            onStartConnectToUser(userID);
                            break;
                        case CONNECTED_TO_USER:
                            onConnectedToUser(userID);
                            break;
                        case CONNECTION_CLOSED_FOR_USER:
                            onConnectionClosedForUser(userID);
                            break;
                        case DISCONNECTED_FROM_USER:
                            onDisconnectedFromUser(userID);
                            break;
                        case DISCONNECTED_TIMEOUT_FROM_USER:
                            onDisconnectedTimeoutFromUser(userID);
                            break;
                        case CONNECTION_FAILED_WITH_USER:
                            onConnectionFailedWithUser(userID);
                            break;
                        case ERROR:
                            onError(exception);
                            break;
                    }
                }
            }
        };
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(CALL_RESULT);
        registerReceiver(callBroadcastReceiver, intentFilter);
    }
}

