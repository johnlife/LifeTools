package com.groupchat.old.activity;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;

import com.groupchat.old.Constants;
import com.groupchat.old.service.IncomeCallListenerService;
import com.quickblox.chat.QBChatService;
import com.quickblox.users.model.QBUser;

public abstract class BaseActivity extends AppCompatActivity implements Constants {

    private static final String TAG = BaseActivity.class.getSimpleName();
    protected QBUser loggedUser;
    private String login;
    private String password;
    private BroadcastReceiver connectivityStateReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initConnectivityStateReceiver();

        QBChatService.setDebugEnabled(true);

        if (isLogin()) {
            loggedUser = QBChatService.getInstance().getUser();
        }
    }

    public void startIncomeCallListenerService(String login, String password, int startServiceVariant){
        Intent tempIntent = new Intent(this, IncomeCallListenerService.class);
        PendingIntent pendingIntent = createPendingResult(LOGIN_TASK_CODE, tempIntent, 0);
        Intent intent = new Intent(this, IncomeCallListenerService.class);
        intent.putExtra(USER_LOGIN, login);
        intent.putExtra(USER_PASSWORD, password);
        intent.putExtra(START_SERVICE_VARIANT, startServiceVariant);
        intent.putExtra(PARAM_PINTENT, pendingIntent);
        startService(intent);
    }

    public void stopIncomeCallListenerService(){
        stopService(new Intent(this, IncomeCallListenerService.class));
    }

    protected String [] getUserDataFromPreferences(){
        String [] userData = new String[2];
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES, Context.MODE_PRIVATE);
        login = sharedPreferences.getString(USER_LOGIN, null);
        password = sharedPreferences.getString(USER_PASSWORD, null);

        userData[0] = login;
        userData[1] = password;

        return userData;
    }

    protected boolean isUserDataEmpty(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES, Context.MODE_PRIVATE);
        login = sharedPreferences.getString(USER_LOGIN, null);
        password = sharedPreferences.getString(USER_PASSWORD, null);
        return TextUtils.isEmpty(login) && TextUtils.isEmpty(password);
    }

    protected void saveUserDataToPreferences(String login, String password){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES, MODE_PRIVATE);
        SharedPreferences.Editor ed = sharedPreferences.edit();
        ed.putString(USER_LOGIN, login);
        ed.putString(USER_PASSWORD, password);
        ed.commit();
    }

    protected void clearUserDataFromPreferences(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES, MODE_PRIVATE);
        SharedPreferences.Editor ed = sharedPreferences.edit();
        ed.remove(USER_LOGIN);
        ed.remove(USER_PASSWORD);
        ed.commit();
    }

    private void reloginToChat(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES, Context.MODE_PRIVATE);
        String login = sharedPreferences.getString(USER_LOGIN, null);
        String password = sharedPreferences.getString(USER_PASSWORD, null);

        if (!TextUtils.isEmpty(login) && !TextUtils.isEmpty(password)) {
            Intent serviceIntent = new Intent(this, IncomeCallListenerService.class);
            serviceIntent.putExtra(USER_LOGIN, login);
            serviceIntent.putExtra(USER_PASSWORD, password);
            serviceIntent.putExtra(START_SERVICE_VARIANT, RELOGIN);
            startService(serviceIntent);
        }
    }

    private void initConnectivityStateReceiver() {
        connectivityStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                boolean isConnected = isNetworkConnected();
                Log.d(TAG, "Connection state was changed. Connected: " + isConnected);
                processCurrentConnectionState(isConnected);
            }
        };

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(connectivityStateReceiver, intentFilter);
    }

    public boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        }
        return false;
    }

    abstract void processCurrentConnectionState(boolean isConnected);

    public void hideSoftKeyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager)  getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
    }

    public boolean isLogin() {
        if (QBChatService.isInitialized() && QBChatService.getInstance().isLoggedIn()) {
            return true;
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        if (connectivityStateReceiver != null) {
            unregisterReceiver(connectivityStateReceiver);
        }
        super.onDestroy();
    }
}





