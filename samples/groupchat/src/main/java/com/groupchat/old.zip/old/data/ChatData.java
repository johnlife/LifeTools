package com.groupchat.old.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ChatData {

    private String name;
    @JsonProperty(value = "isPrivate")
    private boolean isPrivate;
    @JsonProperty(value = "user1")
    private UserData user1;
    @JsonProperty(value = "isUser1Seen")
    private boolean isUser1Seen;
    @JsonProperty(value = "user2")
    private UserData user2;
    @JsonProperty(value = "isUser2Seen")
    private boolean isUser2Seen;

    public ChatData() {}

    public ChatData(String name) {
        this(name, false, null, false, null, false);
    }

    public ChatData(String name, boolean isPrivate, UserData user1, boolean isUser1Seen, UserData user2, boolean isUser2Seen) {
        this.name = name.replaceAll("#", "").replaceAll("'", "").replaceAll("$", "");
        this.isPrivate = isPrivate;
        this.user1 = user1;
        this.isUser1Seen = isUser1Seen;
        this.user2 = user2;
        this.isUser2Seen = isUser2Seen;
    }

    public ChatData(JSONObject json) {
        name = json.optString("name", "default");
        isPrivate = json.optBoolean("isPrivate");
        if (isPrivate) {
            user1 = new UserData(json.optString("user1", ""));
            isUser1Seen = json.optBoolean("isUser1Seen");
            user2 = new UserData(json.optString("user2", ""));
            isUser2Seen = json.optBoolean("isUser2Seen");
        }
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    public boolean equals(Object o) {
        return null != o && o.getClass() == ChatData.class && ((ChatData) o).name.equals(name);
    }

    public boolean isPrivate() {
        return isPrivate;
    }

    public UserData getUser1() {
        return user1;
    }

    public UserData getUser2() {
        return user2;
    }

    public boolean isSeen(String uniqId) {
        if (isPrivate) {
            return uniqId.equals(user1.getUserUniqId()) && isUser1Seen
                    || uniqId.equals(user2.getUserUniqId()) && isUser2Seen;
        }
        return true;
    }

    public boolean isInChat(String uniqId) {
        if (isPrivate()) {
            return uniqId.equals(user1.getUserUniqId()) || uniqId.equals(user2.getUserUniqId());
        }
        return true;
    }

    public String toJson() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("name", name);
            jsonObject.put("isPrivate", isPrivate);
            if (isPrivate) {
                jsonObject.put("user1", user1.toJson());
                jsonObject.put("isUser1Seen", isUser1Seen);
                jsonObject.put("user2", user2.toJson());
                jsonObject.put("isUser2Seen", isUser2Seen);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject.toString();
    }

    public Map<String, Object> toMap(String uniqId) {
        Map<String, Object> map = new HashMap<>();
        if (isInChat(uniqId)) {
            map.put("name", name);
            map.put("isPrivate", isPrivate);
            if (isPrivate) {
                map.put("user1", user1.toMap());
                map.put("user2", user2.toMap());
                map.put(uniqId.equals(user1.getUserUniqId()) ? "isUser1Seen" : "isUser2Seen", true);
            }
        }
        return map;
    }
}
