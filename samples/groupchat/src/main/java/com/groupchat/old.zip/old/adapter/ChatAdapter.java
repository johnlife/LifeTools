package com.groupchat.old.adapter;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.firebase.client.ChildEventListener;
import com.firebase.client.DataSnapshot;
import com.firebase.client.FirebaseError;
import com.firebase.client.Query;
import com.groupchat.old.MessageHandler;
import com.groupchat.old.OnItemClickListener;
import com.groupchat.R;
import com.groupchat.old.customview.RoundedLetterView;
import com.groupchat.old.data.ChatMessageData;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ChatAdapter<T extends ChatMessageData> extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {

    private List<ChatMessageData> originalItems;
    private final int layoutID;
    private final Context context;
    private Query query;
    private MessageHandler messageHandler;
    private String uniqID;
    private List<String> mKeys;
    private ChildEventListener childEventListener;
    private OnItemClickListener<ChatMessageData> itemClickListener;
    private int[] materialCollors;

    public ChatAdapter(Query query, int layoutID, String uniqID, Context context, OnItemClickListener<ChatMessageData> itemClickListener, MessageHandler messageHandler) {
        this.query = query;
        this.messageHandler = messageHandler;
        this.originalItems = new ArrayList<>();
        this.layoutID = layoutID;
        this.context = context;
        mKeys = new ArrayList<>();
        this.itemClickListener = itemClickListener;
        this.uniqID = uniqID;
        initQuerylistener();
    }

    public ChatAdapter(Query query, List<ChatMessageData> originalItems, int layoutID, String uniqID, Context context, OnItemClickListener<ChatMessageData> itemClickListener) {
        this.query = query;
        this.originalItems = originalItems;
        this.layoutID = layoutID;
        this.context = context;
        mKeys = new ArrayList<>();
        this.itemClickListener = itemClickListener;
        this.uniqID = uniqID;
        initQuerylistener();
    }

    public void updateChatRoom(Query query) {
        this.query.removeEventListener(childEventListener);
        this.query = query;
        originalItems.clear();
        mKeys.clear();
        initQuerylistener();
    }

    private void initQuerylistener() {
        childEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                try {
                    ChatMessageData model = dataSnapshot.getValue(ChatMessageData.class);
                    String key = dataSnapshot.getKey();
                    model.setKey(key);
                    if (s == null) {
                        add(model);
                        mKeys.add(0, key);
                    } else {
                        int previousIndex = mKeys.indexOf(s);
                        int nextIndex = previousIndex + 1;
                        if (nextIndex == originalItems.size()) {
                            add(model);
                            mKeys.add(key);
                        } else {
                            add(model, nextIndex);
                            mKeys.add(nextIndex, key);
                        }
                    }
                    if (null != messageHandler) messageHandler.addReadedMessage(key);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                try {
                    ChatMessageData model = dataSnapshot.getValue(ChatMessageData.class);
                    String key = dataSnapshot.getKey();
                    ChatMessageData old = getByKey(key);
                    old.setMessage(model.getMessage());
                    notifyItemChanged(getPosition(old));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
                try {
                    ChatMessageData model = dataSnapshot.getValue(ChatMessageData.class);
                    model.setKey(dataSnapshot.getKey());
                    remove(model);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        };
        query.addChildEventListener(childEventListener);
    }

    private ChatMessageData getByKey(String key) {
        for (ChatMessageData data : originalItems) {
            if (key.equals(data.getKey())) return data;
        }
        return new ChatMessageData();
    }

    public class ChatViewHolder<T extends ChatMessageData> extends RecyclerView.ViewHolder {

        private View user;
        private TextView userName;
        private TextView userMessage;
        private TextView userTime;
        private View group;
        private TextView groupName;
        private TextView groupMessage;
        private TextView groupTime;
        private TextView dateTime;
        private RelativeLayout date;
        private LinearLayout datel;
        private RoundedLetterView groupLetterView;
        private RoundedLetterView userLtterView;

        public ChatViewHolder(View itemView) {
            super(itemView);
            user = itemView.findViewById(R.id.user);
            userName  = (TextView) itemView.findViewById(R.id.user_name);
            userMessage  = (TextView) itemView.findViewById(R.id.user_message);
            userTime  = (TextView) itemView.findViewById(R.id.user_time);
            group = itemView.findViewById(R.id.group);
            groupName  = (TextView) itemView.findViewById(R.id.group_name);
            groupMessage  = (TextView) itemView.findViewById(R.id.group_message);
            groupTime  = (TextView) itemView.findViewById(R.id.group_time);
            groupLetterView = (RoundedLetterView) itemView.findViewById(R.id.rounded_view_group);
            userLtterView = (RoundedLetterView) itemView.findViewById(R.id.rounded_view_user);
            date = (RelativeLayout) itemView.findViewById(R.id.relativeLayoutDate);
            datel = (LinearLayout) itemView.findViewById(R.id.linearLayouttDate);
            dateTime = (TextView) itemView.findViewById(R.id.date);
            obtainMaterialColors();
        }

        private void obtainMaterialColors(){
            TypedArray ta = context.getResources().obtainTypedArray(R.array.mdColors);
            materialCollors = new int[ta.length()];
            for (int i = 0; i < ta.length(); i++) {
                materialCollors[i] = ta.getColor(i, 0);
            }
            ta.recycle();
        }
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        recyclerView.setItemAnimator(getAnimation());
        recyclerView.setLayoutManager(getLayoutManager(getContext()));
    }

    protected RecyclerView.LayoutManager getLayoutManager(Context context) {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        return linearLayoutManager;
    }

    protected DefaultItemAnimator getAnimation() {
        return new DefaultItemAnimator();
    }

    @Override
    public ChatViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(getContext()).inflate(layoutID, parent, false);
        return new ChatViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ChatViewHolder holder, int position) {
        ChatMessageData item = originalItems.get(position);
        SimpleDateFormat sdf2 = new SimpleDateFormat("dd MMMM, yyyy"); //full date
//        SimpleDateFormat sdf = new SimpleDateFormat("EEE dd, HH:mm");// day of the week and number of the day
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");// only time
        Date resultDate = new Date(Long.parseLong(String.valueOf(item.getTime())));
        String time = sdf.format(resultDate);
        String timeDate = sdf2.format(resultDate);
        if(item.isDate()){
            holder.date.setVisibility(View.VISIBLE);
            holder.dateTime.setText(timeDate);
            holder.datel.setVisibility(View.VISIBLE);
        } else {
            holder.date.setVisibility(View.GONE);
            holder.datel.setVisibility(View.GONE);
        }
        if (uniqID.equals(item.getUser().getUserUniqId())) {
            holder.user.setVisibility(View.VISIBLE);
            holder.group.setVisibility(View.GONE);
            holder.dateTime.setText(timeDate);
            holder.userName.setText(item.getUser().getNickName());
            holder.userMessage.setText(item.getMessage());
            holder.userTime.setText(time);
            holder.userLtterView.setTitleText(String.valueOf(item.getUser().getNickName().charAt(0)).toUpperCase());
            holder.userLtterView.setBackgroundColor(stringToColor(item.getUser().getNickName()));
        } else {
            holder.group.setVisibility(View.VISIBLE);
            holder.user.setVisibility(View.GONE);
            holder.dateTime.setText(timeDate);
            holder.groupName.setText(item.getUser().getNickName());
            holder.groupMessage.setText(item.getMessage());
            holder.groupTime.setText(time);
            holder.groupLetterView.setTitleText(String.valueOf(item.getUser().getNickName().charAt(0)).toUpperCase());
            holder.groupLetterView.setBackgroundColor(stringToColor(item.getUser().getNickName()));
        }
    }

    private int stringToColor(String str) {
        return materialCollors[Math.abs(str.hashCode() % materialCollors.length)];
    }

    private int dateParse(ChatMessageData item) {
        int ii = 0;
        if(originalItems.size() > 0 && (originalItems.indexOf(item) != 0)){
            ChatMessageData itemOld = originalItems.get(originalItems.indexOf(item) - 1);
            SimpleDateFormat sdf = new SimpleDateFormat("dd MM, yyyy");
            Date resultDate = new Date(Long.parseLong(String.valueOf(item.getTime())));
            String timeDate = sdf.format(resultDate);
            Date resultDateOld = new Date(Long.parseLong(String.valueOf(itemOld.getTime())));
            String timeDateOld = sdf.format(resultDateOld);
            if ((!timeDate.equals(timeDateOld))) {
                ii = 999;
            }
        }
        if(originalItems.size() == 1){
            ii = 999;
        }
        return ii;
    }

    @Override
    public void onBindViewHolder(ChatViewHolder holder, final int position, List<Object> payloads) {
        super.onBindViewHolder(holder, position, payloads);
        AdapterView.OnLongClickListener listener = new AdapterView.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (itemClickListener != null) return itemClickListener.onItemLongClicked(getItem(position), v, position);
                return false;
            }
        };
        AdapterView.OnClickListener onClickListener = new AdapterView.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (itemClickListener != null) itemClickListener.onItemClicked(getItem(position), v, position);
            }
        };
        holder.user.setOnClickListener(onClickListener);
        holder.group.setOnClickListener(onClickListener);
        holder.user.setOnLongClickListener(listener);
        holder.group.setOnLongClickListener(listener);
    }

    @Override
    public int getItemCount() {
        return originalItems.size();
    }

    public void add(ChatMessageData item) {
        originalItems.add(item);
        if(dateParse(item) == 999){
            item.setDate(true);
        } else item.setDate(false);
        notifyItemInserted(originalItems.size() - 1);
    }

    public void add(ChatMessageData item, int position) {
        originalItems.add(position, item);
        notifyItemInserted(position);
    }

    public void addAll(List<ChatMessageData> list) {
        originalItems.addAll(list);
        notifyItemRangeInserted(originalItems.size() - list.size() - 1, list.size());
    }

    public void addAll(List<ChatMessageData> list, int startPosition) {
        originalItems.addAll(startPosition, list);
        notifyItemRangeInserted(startPosition, list.size());
    }

    public void clear() {
        notifyItemRangeRemoved(0, originalItems.size() - 1);
        originalItems.clear();
    }

    public void remove(ChatMessageData item) {
        int position = originalItems.indexOf(item);
        originalItems.remove(item);
        notifyItemRemoved(position);
    }

    public ChatMessageData getItem(int position) {
        return originalItems.get(position);
    }

    public int getPosition ( ChatMessageData data) {
        for (int i = 0 ;i < originalItems.size(); i++) {
            if (getItem(i).getKey().equals(data.getKey())) return i;
        }
        return  - 1;
    }

    public List<ChatMessageData> getAll() {
        return originalItems;
    }

    public Context getContext() {
        return context;
    }


}
