package com.groupchat.old;

/**
 * Created by Aleksandr on 22.10.2015.
 */
public interface MessageHandler {
    void addReadedMessage(String key);
}
