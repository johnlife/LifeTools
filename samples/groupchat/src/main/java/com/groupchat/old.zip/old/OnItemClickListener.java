package com.groupchat.old;

import android.view.View;

public interface OnItemClickListener<T> {
    void onItemClicked(T item, View itemView, int position);
    boolean onItemLongClicked(T item, View itemView, int position);
}
