package com.groupchat.old.service;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.preference.PreferenceManager;
import android.support.v4.content.WakefulBroadcastReceiver;

import com.groupchat.old.Constants;

public class BootReceiver extends WakefulBroadcastReceiver implements Constants{

    @Override
    public void onReceive(Context context, Intent intent) {
        if (PreferenceManager.getDefaultSharedPreferences(context).contains(PREFS_KEY_USER)) {
            ComponentName messageService = new ComponentName(context.getPackageName(), MessageService.class.getName());
            startWakefulService(context, intent.setComponent(messageService));
            ComponentName callService = new ComponentName(context.getPackageName(), IncomeCallListenerService.class.getName());
            startWakefulService(context, intent.setComponent(callService));
            if (isOrderedBroadcast()) setResultCode(Activity.RESULT_OK);
        }
    }
}
