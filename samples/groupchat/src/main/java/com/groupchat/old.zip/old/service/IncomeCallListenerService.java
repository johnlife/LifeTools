package com.groupchat.old.service;

import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.groupchat.old.Constants;
import com.groupchat.old.activity.CallActivity;
import com.groupchat.old.app.GroupChatApplication;
import com.groupchat.old.util.Strings;
import com.quickblox.auth.QBAuth;
import com.quickblox.auth.model.QBSession;
import com.quickblox.chat.QBChatService;
import com.quickblox.chat.QBSignaling;
import com.quickblox.chat.QBWebRTCSignaling;
import com.quickblox.chat.listeners.QBVideoChatSignalingManagerListener;
import com.quickblox.core.QBEntityCallbackImpl;
import com.quickblox.core.QBSettings;
import com.quickblox.core.request.QBPagedRequestBuilder;
import com.quickblox.users.QBUsers;
import com.quickblox.users.model.QBUser;
import com.quickblox.videochat.webrtc.QBRTCClient;
import com.quickblox.videochat.webrtc.QBRTCConfig;
import com.quickblox.videochat.webrtc.QBRTCException;
import com.quickblox.videochat.webrtc.QBRTCSession;
import com.quickblox.videochat.webrtc.callbacks.QBRTCClientConnectionCallbacks;
import com.quickblox.videochat.webrtc.callbacks.QBRTCClientSessionCallbacks;

import org.jivesoftware.smack.SmackException;
import org.webrtc.VideoCapturerAndroid;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IncomeCallListenerService extends Service implements QBRTCClientSessionCallbacks, QBRTCClientConnectionCallbacks, Constants {

    private static final String TAG = IncomeCallListenerService.class.getSimpleName();

    private QBChatService chatService;
    private String login;
    private String password;
    private PendingIntent pendingIntent;
    private int startServiceVariant;
    private BroadcastReceiver connectionStateReceiver;
    private boolean needMaintainConnectivity;

    @Override
    public void onCreate() {
        super.onCreate();
        QBSettings.getInstance().fastConfigInit(APP_ID, AUTH_KEY, AUTH_SECRET);
        initConnectionManagerListener();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startServiceVariant = AUTOSTART;

        if (!QBChatService.isInitialized()) {
            QBChatService.init(getApplicationContext());
        }

        chatService = QBChatService.getInstance();

        if (intent != null && intent.getExtras()!= null) {
            pendingIntent = intent.getParcelableExtra(PARAM_PINTENT);
            parseIntentExtras(intent);
        }
        if (TextUtils.isEmpty(login) && TextUtils.isEmpty(password)){
            getUserDataFromPreferences();
        }

        if (!TextUtils.isEmpty(login) && !TextUtils.isEmpty(password)) {
            if (!QBChatService.getInstance().isLoggedIn()) {
                checkUser(login, password);
            } else {
                startActionsOnSuccessLogin(login, password);
            }
        }

        return START_STICKY;
    }

    private void initQBRTCClient() {
        try {
            QBChatService.getInstance().startAutoSendPresence(60);
        } catch (SmackException.NotLoggedInException e) {
            e.printStackTrace();
        }

        // Add signalling manager
        QBChatService.getInstance().getVideoChatWebRTCSignalingManager().addSignalingManagerListener(new QBVideoChatSignalingManagerListener() {
            @Override
            public void signalingCreated(QBSignaling qbSignaling, boolean createdLocally) {
                if (!createdLocally) {
                    QBRTCClient.getInstance().addSignaling((QBWebRTCSignaling) qbSignaling);
                }
            }
        });

        QBRTCClient.getInstance().setCameraErrorHendler(new VideoCapturerAndroid.CameraErrorHandler() {
            @Override
            public void onCameraError(final String s) {
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
            }
        });

        QBRTCConfig.setAnswerTimeInterval(ANSWER_TIME_INTERVAL);

        // Add activity as callback to RTCClient
        QBRTCClient.getInstance().addSessionCallbacksListener(this);
        QBRTCClient.getInstance().addConnectionCallbacksListener(this);

        // Start mange QBRTCSessions according to VideoCall parser's callbacks
        QBRTCClient.getInstance().prepareToProcessCalls(getApplicationContext());
    }

    private void parseIntentExtras(Intent intent) {
        login = intent.getStringExtra(USER_LOGIN);
        password = intent.getStringExtra(USER_PASSWORD);
        startServiceVariant = intent.getIntExtra(START_SERVICE_VARIANT, AUTOSTART);
    }

    protected void getUserDataFromPreferences(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES, Context.MODE_PRIVATE);
        login = sharedPreferences.getString(USER_LOGIN, null);
        password = sharedPreferences.getString(USER_PASSWORD, null);
    }

    private void createSession(final QBUser user) {
        QBAuth.createSession(user, new QBEntityCallbackImpl<QBSession>() {
            @Override
            public void onSuccess(QBSession session, Bundle bundle) {
                user.setId(session.getUserId());

                if (chatService.isLoggedIn()) {
                    startActionsOnSuccessLogin(user.getFullName(), user.getPassword());
                } else {
                    chatService.login(user, new QBEntityCallbackImpl<QBUser>() {

                        @Override
                        public void onSuccess() {
                            startActionsOnSuccessLogin(user.getFullName(), user.getPassword());
                        }

                        @Override
                        public void onError(List errors) {
                            if (errors.contains("Unauthorized")) {
                                sendResultToActivity(NEED_PASSWORD);
                            } else {
                                showErrors(errors);
                                sendResultToActivity(LOGIN_FAILED);
                            }
                        }
                    });
                }
            }

            @Override
            public void onError(List<String> errors) {
                if (errors.contains("Unauthorized")) {
                    sendResultToActivity(NEED_PASSWORD);
                } else {
                    showErrors(errors);
                    sendResultToActivity(LOGIN_FAILED);
                }
            }
        });
    }

    private void checkUser(final String login, final String password) {
        QBAuth.createSession(new QBEntityCallbackImpl<QBSession>() {
            @Override
            public void onSuccess(QBSession session, Bundle bundle) {
                QBPagedRequestBuilder pagedRequestBuilder = new QBPagedRequestBuilder();
                pagedRequestBuilder.setPage(1);
                pagedRequestBuilder.setPerPage(100);
                QBUsers.getUsers(pagedRequestBuilder, new QBEntityCallbackImpl<ArrayList<QBUser>>() {
                    @Override
                    public void onSuccess(ArrayList<QBUser> users, Bundle params) {
                        QBUser checkingUser = new QBUser(Strings.SHA1(login), password);
                        checkingUser.setFullName(login);
                        if (checkingUser == null) {
                            showError("user == null");
                            return;
                        }
                        for (QBUser user : users) {
                            if (user.getLogin().equals(checkingUser.getLogin())) {
                                user.setPassword(password);
                                createSession(user);
                                return;
                            }
                        }
                        QBUsers.signUp(checkingUser, new QBEntityCallbackImpl<QBUser>() {
                            @Override
                            public void onSuccess(QBUser user, Bundle args) {
                                user.setPassword(password);
                                createSession(user);
                            }

                            @Override
                            public void onError(List<String> errors) {
                                showErrors(errors);
                                sendResultToActivity(LOGIN_FAILED);
                            }
                        });
                    }

                    @Override
                    public void onError(List<String> errors) {
                        showErrors(errors);
                    }
                });
            }

            @Override
            public void onError(List<String> errors) {
                showErrors(errors);
                sendResultToActivity(LOGIN_FAILED);
            }
        });
    }

    private void startActionsOnSuccessLogin(String login, String password) {
        initQBRTCClient();
        sendResultToActivity(LOGIN_SUCCESS);
        saveUserDataToPreferences(login, password);
        needMaintainConnectivity = true;
    }

    private void saveUserDataToPreferences(String login, String password){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES, MODE_PRIVATE);
        SharedPreferences.Editor ed = sharedPreferences.edit();
        ed.putString(USER_LOGIN, login);
        ed.putString(USER_PASSWORD, password);
        ed.commit();
    }

    private void sendResultToActivity(int result){
        if ((startServiceVariant == SIGNIN || startServiceVariant == SIGNUP) && pendingIntent != null) {
            try {
                Intent intent = new Intent();
                intent.putExtra(LOGIN_RESULT, result);
                intent.putExtra(USER_LOGIN, login);
                pendingIntent.send(IncomeCallListenerService.this, LOGIN_RESULT_CODE, intent);
            } catch (PendingIntent.CanceledException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onDestroy() {
        try {
            QBChatService.getInstance().logout();
        } catch (SmackException.NotConnectedException e) {
            e.printStackTrace();
        }
        QBRTCClient.getInstance().removeSessionsCallbacksListener(this);
        QBRTCClient.getInstance().removeConnectionCallbacksListener(this);
        GroupChatApplication.setCurrentSession(null);

        if (connectionStateReceiver != null){
            unregisterReceiver(connectionStateReceiver);
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
    }


    private void initConnectionManagerListener() {
        connectionStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                Log.d(TAG, "Connection state was changed");
                boolean isConnected = processConnectivityState(intent);
                updateStateIfNeed(isConnected);
            }

            private boolean processConnectivityState(Intent intent) {
                int connectivityType = intent.getIntExtra(ConnectivityManager.EXTRA_NETWORK_TYPE, -1);
                // Check does connectivity equal mobile or wifi types
                boolean connectivityState = false;
                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo networkInfo = cm.getActiveNetworkInfo();

                if (networkInfo != null){
                    if (connectivityType == ConnectivityManager.TYPE_MOBILE
                            || connectivityType == ConnectivityManager.TYPE_WIFI
                            || networkInfo.getTypeName().equals("WIFI")
                            || networkInfo.getTypeName().equals("MOBILE")) {
                        //should check null because in air plan mode it will be null
                        if (networkInfo.isConnected()) {
                            // Check does connectivity EXISTS for connectivity type wifi or mobile internet
                            // Pay attention on "!" symbol  in line below
                            connectivityState = true;
                        }
                    }
                }
                return connectivityState;
            }

            private void updateStateIfNeed(boolean connectionState) {
                if (connectionState) {
                    processCurrentConnectionState(connectionState);
                }
            }

            private void processCurrentConnectionState(boolean isConnected) {
                if (!isConnected) {
                    Log.d(TAG, "Connection is turned off");
                } else {
                    if (needMaintainConnectivity) {
                        Log.d(TAG, "Connection is turned on");
                        if (!QBChatService.isInitialized()) {
                            QBChatService.init(getApplicationContext());
                        }
                        chatService = QBChatService.getInstance();
                        if (!QBChatService.getInstance().isLoggedIn()) {
                            SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES, Context.MODE_PRIVATE);
                            String login = sharedPreferences.getString(USER_LOGIN, null);
                            String password = sharedPreferences.getString(USER_PASSWORD, null);
                            reloginToChat(login, password);
                        }
                    }
                }
            }

        };

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(connectionStateReceiver, intentFilter);
    }

    private void reloginToChat(String login, String password) {
        final QBUser user = new QBUser(login, password);
        QBAuth.createSession(login, password, new QBEntityCallbackImpl<QBSession>() {
            @Override
            public void onSuccess(QBSession session, Bundle bundle) {
                user.setId(session.getUserId());
                chatService.login(user, new QBEntityCallbackImpl<QBUser>() {

                    @Override
                    public void onSuccess(QBUser result, Bundle params) {}

                    @Override
                    public void onSuccess() {}

                    @Override
                    public void onError(List errors) {
                        showErrors(errors);
                    }
                });
            }

            @Override
            public void onSuccess() {
                super.onSuccess();
            }

            @Override
            public void onError(List<String> errors) {
                showErrors(errors);
            }
        });
    }

    private void showError(String error) {
        Log.d(TAG, error);
        Toast.makeText(this, error, Toast.LENGTH_LONG).show();
    }

    private void showErrors(List<String> errors) {
        StringBuilder error = new StringBuilder();
        for (int i = 0; i < errors.size(); i++) {
            error.append(errors.get(i));
            if (i < errors.size() - 1) {
                error.append("\n");
            }
            Log.d(TAG, errors.get(i));
        }
        Toast.makeText(this, error, Toast.LENGTH_LONG).show();
    }

    private void sendBroadcastMessages(int callbackAction, Integer usedID,
                                       Map<String, String> userInfo, QBRTCException exception){
        Intent intent = new Intent();
        intent.setAction(CALL_RESULT);
        intent.putExtra(CALL_ACTION_VALUE, callbackAction);
        intent.putExtra(USER_ID, usedID);
        intent.putExtra(USER_INFO_EXTRAS, (Serializable) userInfo);
        intent.putExtra(QB_EXCEPTION_EXTRAS, exception);
        sendBroadcast(intent);
    }


    //========== Implement methods ==========//

    @Override
    public void onReceiveNewSession(QBRTCSession qbrtcSession) {
        if (GroupChatApplication.getCurrentSession() == null){
            GroupChatApplication.setCurrentSession(qbrtcSession);
            CallActivity.start(this,
                    qbrtcSession.getConferenceType(),
                    qbrtcSession.getOpponents(),
                    qbrtcSession.getUserInfo(),
                    CALL_DIRECTION_TYPE.INCOMING);
            sendBroadcastMessages(RECEIVE_NEW_SESSION, qbrtcSession.getCallerID(), qbrtcSession.getUserInfo(), null);
        } else if (GroupChatApplication.getCurrentSession() != null && !qbrtcSession.equals(GroupChatApplication.getCurrentSession())){
                qbrtcSession.rejectCall(new HashMap<String, String>());
        }
    }

    @Override
    public void onUserNotAnswer(QBRTCSession qbrtcSession, Integer integer) {
        sendBroadcastMessages(USER_NOT_ANSWER, integer, null, null);
    }

    @Override
    public void onCallRejectByUser(QBRTCSession qbrtcSession, Integer integer, Map<String, String> map) {
        sendBroadcastMessages(CALL_REJECT_BY_USER, integer, map, null);
    }

    @Override
    public void onReceiveHangUpFromUser(QBRTCSession qbrtcSession, Integer integer) {
        if (qbrtcSession.equals(GroupChatApplication.getCurrentSession())) {
            sendBroadcastMessages(RECEIVE_HANG_UP_FROM_USER, integer, null, null);
        }
    }

    @Override
    public void onSessionClosed(QBRTCSession qbrtcSession) {
        if (qbrtcSession.equals(GroupChatApplication.getCurrentSession())) {
            sendBroadcastMessages(SESSION_CLOSED, null, null, null);
        }
    }

    @Override
    public void onSessionStartClose(QBRTCSession qbrtcSession) {
        sendBroadcastMessages(SESSION_START_CLOSE, null, null, null);
    }

    @Override
    public void onStartConnectToUser(QBRTCSession qbrtcSession, Integer integer) {
        sendBroadcastMessages(START_CONNECT_TO_USER, integer, null, null);
    }

    @Override
    public void onConnectedToUser(QBRTCSession qbrtcSession, Integer integer) {
        sendBroadcastMessages(CONNECTED_TO_USER, integer, null, null);
    }

    @Override
    public void onConnectionClosedForUser(QBRTCSession qbrtcSession, Integer integer) {
        sendBroadcastMessages(CONNECTION_CLOSED_FOR_USER, integer, null, null);
    }

    @Override
    public void onDisconnectedFromUser(QBRTCSession qbrtcSession, Integer integer) {
        sendBroadcastMessages(DISCONNECTED_FROM_USER, integer, null, null);
    }

    @Override
    public void onDisconnectedTimeoutFromUser(QBRTCSession qbrtcSession, Integer integer) {
        sendBroadcastMessages(DISCONNECTED_TIMEOUT_FROM_USER, integer, null, null);
    }

    @Override
    public void onConnectionFailedWithUser(QBRTCSession qbrtcSession, Integer integer) {
        sendBroadcastMessages(CONNECTION_FAILED_WITH_USER, integer, null, null);
    }

    @Override
    public void onError(QBRTCSession qbrtcSession, QBRTCException e) {
        sendBroadcastMessages(ERROR, null, null, null);
    }
}
